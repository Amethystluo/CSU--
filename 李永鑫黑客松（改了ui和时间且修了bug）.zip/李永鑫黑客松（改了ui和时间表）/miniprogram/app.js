App({globalData:{traffic:null}})
